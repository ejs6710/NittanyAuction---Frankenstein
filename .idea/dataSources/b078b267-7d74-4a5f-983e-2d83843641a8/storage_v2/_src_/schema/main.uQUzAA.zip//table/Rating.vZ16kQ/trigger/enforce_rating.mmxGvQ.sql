CREATE TRIGGER enforce_rating
BEFORE INSERT ON Rating
FOR EACH ROW
WHEN NOT EXISTS(
   SELECT 1
   FROM Transactions
   WHERE bidder_email = NEW.bidder_email AND seller_email = NEW.seller_email
)
AND (SELECT enforce_rating FROM Trigger_Settings) = 1
BEGIN
   SELECT RAISE(ABORT, 'Error: You cannot rate a seller without completing a transaction');
end;


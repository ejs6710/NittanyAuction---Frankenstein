CREATE TRIGGER check_auction
AFTER INSERT ON Bids
FOR EACH ROW
WHEN (
   SELECT COUNT(*)
   FROM Bids B
   WHERE B.listing_id = NEW.listing_id AND B.seller_email = NEW.seller_email
   ) >= (
   SELECT A.max_bids
     FROM Auction_Listings A
     WHERE A.listing_id = NEW.listing_id AND A.seller_email = NEW.seller_email
   )
AND (SELECT check_auction FROM Trigger_Settings) = 1
BEGIN
   UPDATE Auction_Listings
   SET status = 2
   WHERE listing_id = NEW.listing_id and seller_email = NEW.seller_email;
End;


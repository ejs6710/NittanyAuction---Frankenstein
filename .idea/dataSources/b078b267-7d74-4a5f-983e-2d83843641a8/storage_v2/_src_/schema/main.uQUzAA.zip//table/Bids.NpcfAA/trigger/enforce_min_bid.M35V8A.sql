CREATE TRIGGER enforce_min_bid
BEFORE INSERT ON Bids
FOR EACH ROW
   WHEN NEW.bid_price < (
       SELECT COALESCE(MAX(B.bid_price), 0) + 1
       FROM Bids B
       WHERE B.listing_id = NEW.listing_id
       AND B.seller_email = NEW.seller_email)
   AND (SELECT enforce_min_bid FROM Trigger_Settings) = 1
BEGIN
   SELECT RAISE(ABORT, 'Error: New bid must be at least $1 higher than the current highest bid.');


END;

